# ENABLE SPHINX TO ACCESS THE GIT LOG
"""
.. git_changelog::
    :revisions: 99
    :detailed-message-pre: True
"""
