=================================================================
validation - Functionality for validating a pandas data structure
=================================================================
Module providing ``pandas`` data structure validation functionality.

.. automodule:: validation
    :members:
    :undoc-members:
    :private-members:
    :special-members:
    :exclude-members: ErrorInfo, ValidationWarning, __dict__, __module__, __weakref__
    :show-inheritance:
